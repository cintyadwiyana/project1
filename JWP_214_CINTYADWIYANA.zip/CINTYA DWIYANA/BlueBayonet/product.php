<?php include "header.php";?>

<div class="products">
	<div class="container">
		
		<div class="col-md-12 products-right">
			
			<div class="products-right-grids-bottom">
			<a href="images/1.jpg" download>SILAHKAN MELAKUKAN PEMBAYARAN REGISTRASI</a>
				<?php $sql = "select * from barang where nama_barang like '%$search%' order by 2";
				$a = mysqli_query($dbc, $sql) or die(mysqli_error($dbc));
				$i = 0;
				while($b = mysqli_fetch_object($a)){ ?>
			
				<?php if($i % 3 == 0) { ?>
				<div class="col-md-12 products-right-grids-bottom-grid">
				<?php }?>
					<div class="col-md-4">
						
								</p>
							</div>
						</div>
					</div>
					
					</div>
				<?php $i++; if($i % 4 == 0) { ?>
				</div>
				<?php }}?>
				
				<div class="clearfix"> </div>
				
			</div>
			
		</div>
		<div class="clearfix"> </div>
	</div>
</div>
<?php include "footer.php";?>