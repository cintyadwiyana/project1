<?php session_start(); include "connect.php"; // fungsi database
// digunakan untuk cek username + password
	$id = $_POST['id'];
	$atas = $_POST['atas'];
	$bank = $_POST['bank'];
	$norek = $_POST['norek'];
	$jumlah = $_POST['jumlah'];
	$tujuan = $_POST['tujuan'];
	$gambar = "";
if (!empty($_FILES['gambar']['name']))
{
	$gambar = $_FILES['gambar']['name'];
	move_uploaded_file($_FILES['gambar']['tmp_name'], "bukti/".$_FILES['gambar']['name']);
}
	
		$data = array(
			"id_pembayaran"=>getNextIdFull('pembayaran', 'id_pembayaran', 'BY'),
			"id_pemesanan"=>($id),
			"atas_nama"=>$atas,
			"tujuan_transfer"=>$tujuan,
			"jumlah_pembayaran"=>$jumlah,
			"no_rekening"=>$norek,
			"tgl_pembayaran"=>date('Y-m-d'),
			"nama_bank"=>$bank,
			"foto"=>$gambar,
		);
		insert("pembayaran", $data);
		$_SESSION['e'] = 'Terima kasih, pembayaran berhasil dikonfirmasi.';
		
		mysqli_query($dbc, "update pemesanan set status_pemesanan = 'Verifikasi Pembayaran' where kd_pemesanan = '$id'") or die(mysqli_error($dbc));
		
				
		header('Location:detailorder.php?id=' . $id); // pindahkan ke halaman index
	
?>