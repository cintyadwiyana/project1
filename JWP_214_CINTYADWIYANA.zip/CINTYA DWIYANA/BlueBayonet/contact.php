<?php include "header.php";?>
<!-- breadcrumbs -->
	<div class="breadcrumbs">
		<div class="container">
			<ol class="breadcrumb breadcrumb1 animated wow slideInLeft" data-wow-delay=".5s">
				<li><a href="index.php"><span class="glyphicon glyphicon-home" aria-hidden="true"></span>Home</a></li>
				<li class="active">Contact Us</li>
			</ol>
		</div>
	</div>
<!-- //breadcrumbs -->
<!-- register -->
	<div class="register">
		<div class="container">
			<h3 class="animated wow zoomIn" data-wow-delay=".5s">Contact Us</h3>
			
			<div class="login-form-grids">
				<form method="post" action="docontact.php" class="animated wow slideInUp" data-wow-delay=".5s">
					<input type="text" name="nama" placeholder="Nama..." required=" " >
					<input type="email" name="email" placeholder="Email..." required=" " >
					
					<input type="text" name="subjek" placeholder="Subjek..." required=" " >
				
					
						
					<input type="text" name="isi" placeholder="Pesan..." required=" " >
					<input type="submit" value="Kirim">
				</form>
			</div>
		
		</div>
	</div>
<!-- //register -->
<?php include "footer.php";?>