<?php include "header.php";

$diskon = 0;
$total = 0;
$id = $_GET['id'];

$sql = "select jumlah_diskon from diskon where kd_diskon = (select kd_diskon from pemesanan where kd_pemesanan = '$id')";
$a = mysqli_query($dbc, $sql) or die(mysqli_error($dbc));
$b = mysqli_fetch_object($a);
$diskon = 0;
if($b)
	$diskon = $b->jumlah_diskon;
?>
<!-- //header -->
<!-- breadcrumbs -->
	<div class="breadcrumbs">
		<div class="container">
			<ol class="breadcrumb breadcrumb1 animated wow slideInLeft" data-wow-delay=".5s">
				<li><a href="index.php"><span class="glyphicon glyphicon-home" aria-hidden="true"></span>Home</a></li>
				<li class="active">Detail Pesanan <?php echo $id;?></li>
			</ol>
		</div>
	</div>
<!-- //breadcrumbs -->
<!-- checkout -->

				<div class="checkout" style="">
				  <div class="container">
				    
				    <div class="checkout-right animated wow slideInUp" data-wow-delay=".5s">
				      <table width="413" border="0" align="center">
				        <tbody>
				          <tr>
				            <td colspan="3">Nomor Rekening UNIVERSITAS ABC Co. di bawah ini :</td>
			              </tr>
				          <tr>
				            <td colspan="3">&nbsp;</td>
			              </tr>
				          <tr>
				            <td width="198"><img src="images/Mandiri.png" width="159" height="48" alt=""/></td>
				            <td width="144">&nbsp;</td>
				            <td width="57">&nbsp;</td>
			              </tr>
				          <tr>
				            <td align="center"> 900-00-3640-141-3</td>
				            <td>a/n Zhen Rezky</td>
				            <td>&nbsp;</td>
			              </tr>
				          <tr>
				            <td height="40">&nbsp;</td>
				            <td>&nbsp;</td>
				            <td>&nbsp;</td>
			              </tr>
				          <tr>
				            <td><img src="images/logo-bank-bca1.jpg" width="145" height="48" alt=""/></td>
				            <td>&nbsp;</td>
				            <td>&nbsp;</td>
			              </tr>
				          <tr>
				            <td align="center">817-061-5329</td>
				            <td>a/n Zhen Rezky </td>
				            <td>&nbsp;</td>
			              </tr>
				          <tr>
				            <td>&nbsp;</td>
				            <td>&nbsp;</td>
				            <td>&nbsp;</td>
			              </tr>
				          <tr>
				            <td>&nbsp;</td>
				            <td>&nbsp;</td>
				            <td>&nbsp;</td>
			              </tr>
				          <tr>
				            <td colspan="3">Jangan lupa Konfirmasi Pesanan anda setelah melakukan pembayaran</td>
			              </tr>
			            </tbody>
			          </table>
				      <p>&nbsp;</p>
				      <p>&nbsp;</p>
				      <p>&nbsp;</p>
				      <p>Detail Pesanan Anda</p>
				      <table class="timetable_sub">
				        <thead>
				          <tr>
				            <th>No.</th>
				            <th>Nama Kompetisi</th>
				            <th>Jadwal Pertandingan</th>
				            <th>Jumlah</th>
				            <th>Harga</th>
				            <th>Sub Total</th>
			              </tr>
			            </thead>
				        <?php $no = 1;
					$total = 0;
					$sql = "select * from detail_pemesanan a 
					join barang b on a.kd_barang = b.kd_barang 
					
					join warna c on c.kd_warna = a.kd_warna
					join ukuran d on d.kd_ukuran = a.kd_ukuran
					join cuttingan e on e.kd_cuttingan = a.kd_cuttingan
					
					where kd_pemesanan = '$id'";
					$a = mysqli_query($dbc, $sql) or die(mysqli_error($dbc));
					while($b = mysqli_fetch_object($a)) {?>
				        <tr class="rem1">
				          <td class="invert"><?php echo $no++;?></td>
				          <td class="invert-image"><?php echo $b->nama_barang;?></td>
				          <td class="invert"><?php echo $b->nama_warna;?></td>
				          <td class="invert"><?php echo $b->nama_ukuran;?></td>
				          <td class="invert"><?php echo $b->nama_cuttingan;?></td>
				          <td class="invert"><?php echo $b->jumlah;?></td>
				          <td class="invert"><?php echo number_format($b->harga_asli);?></td>
				          <td class="invert"><?php $total+=($b->jumlah * $b->harga_asli);
							echo number_format($b->jumlah * $b->harga_asli);?></td>
			            </tr>
				        <?php }?>
				        <tr>
				          <td colspan="7">Total</td>
				          <td><?php echo number_format($total);?></td>
			            </tr>
				        <tr>
				          <td colspan="7">Ongkir</td>
				          <td><?php 
						$sql = "select harga_ongkir from ongkir a join pemesanan b on a.kd_ongkir = b.kd_ongkir where kd_pemesanan = '$id'";
						$a = mysqli_query($dbc, $sql) or die(mysqli_error($dbc));
						$b = mysqli_fetch_object($a);
						$ongkir = $b->harga_ongkir;
						echo number_format($ongkir);?></td>
			            </tr>
				        <tr>
				          <td colspan="7">Diskon</td>
				          <td><?php echo number_format($diskon);?>%</td>
			            </tr>
				        <tr>
				          <td colspan="7">Grand Total</td>
				          <td><?php $gt = $total+$ongkir;
						echo number_format($gt - ($gt * $diskon / 100));?></td>
			            </tr>
				        <!--quantity-->
			          </table>
				    </div>
				  </div>
				</div>
				<p>
				  <?php 
					$sql = "select * from pemesanan a
		where a.kd_pemesanan = '" . $id . "'";
	$x = mysqli_query($dbc, $sql) or die(mysqli_error($dbc));
	$y = mysqli_fetch_object($x) ;
	if($y->status_pemesanan == 'Menunggu Pembayaran')
	{ 





						$sql = "select harga_ongkir from ongkir a join pemesanan b on a.kd_ongkir = b.kd_ongkir where kd_pemesanan = '$id'";
						$a = mysqli_query($dbc, $sql) or die(mysqli_error($dbc));
						$b = mysqli_fetch_object($a);
						$ongkir = $b->harga_ongkir;
						
						
						$sql = "select sum(jumlah * harga_asli) as total from detail_pemesanan a join barang b on a.kd_barang = b.kd_barang where kd_pemesanan = '$id'";
						
						$a = mysqli_query($dbc, $sql) or die(mysqli_error($dbc));
						$b = mysqli_fetch_object($a);
						$total = $b->total;
						$gt = $ongkir + $total;
						$gt = $gt - ($gt * $diskon / 100);
						
?>
</p>
<div class="login">
		<div class="container">
			<h3 class="animated wow zoomIn" data-wow-delay=".5s">Konfirmasi Pembayaran</h3>
			<p class="est animated wow zoomIn" data-wow-delay=".5s"></p>
			<div class=" animated wow slideInUp" data-wow-delay=".5s">
			
<form method="post" action="dopayment.php" enctype="multipart/form-data">		
	<input type="hidden" name="id" value="<?php echo $id;?>"/>
	<div class="form-group">
		<span><label>Jumlah Pembayaran</label></span><p>&nbsp;</p>
		<input name="jumlah" type="hidden" value="<?php echo $gt;?>"/>
		<span><input name="jumlah2" disabled value="<?php echo number_format($gt);?>" type="text" min="0" required autofocus class="textbox form-control"></span>
	</div>
	<div class="form-group">
		<span><label>Bank</label></span><p>&nbsp;</p>
		<span><input name="bank" type="text" required  class="textbox form-control"></span>
	</div>
	<div class="form-group">
		<span><label>No Rekening</label></span><p>&nbsp;</p>
		<span><input name="norek" type="text" required  class="textbox form-control"></span>
	</div>
	<div class="form-group">
		<span><label>Atas Nama</label></span><p>&nbsp;</p>
		<span><input name="atas" type="text" required  class="textbox form-control"></span>
	</div>
	<div class="form-group">
		<span><label>Tujuan Transfer</label></span><p>&nbsp;</p>
		<select name="tujuan" class="form-control">
			<option value="BCA - 817-061-5329">BCA - 817-061-5329</option>
			<option value="Mandiri - 900-00-3640-141-3">Mandiri - 900-00-3640-141-3</option>
		</select>
	</div>
	<div class="form-group">
		<span><label>Foto Bukti Pembayaran</label></span><p>&nbsp;</p>
		<span><input accept="image/*" name="gambar" type="file" required  class="textbox"></span>
	</div>	

<input type="submit" class="btn btn-primary" style="color:white !important;" value="Konfirmasi Pembayaran"/>
	
		
</form>
</div>			
		</div>
	</div>

	<?php } ?>
<!-- //checkout -->
<?php include "footer.php";?>