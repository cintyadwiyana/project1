<?php session_start(); include "connect.php"; // fungsi db
// digunakan untuk cek email + password
	$email = $_POST['email'];
	$password = md5($_POST['password']);
	$count = 0;	
	$result = mysqli_query($dbc, "select * from pelanggan where email = '$email' and password='$password'") or die( mysqli_error($dbc)); // cek email dan password

	$count = mysqli_num_rows($result); // hitung jumlah data
	
	if($count == 0) // jika 0 maka email password salah
	{		
		$_SESSION['e'] = 'Email atau Password tidak terdaftar, silakan mendaftar atau coba lagi';
		header('Location:login.php');
	}
	else
	{				
		$_SESSION['a'] = mysqli_result($result, 0, 0);
		$_SESSION['b'] = mysqli_result($result, 0, 1);		
		$_SESSION['e'] = 'Login berhasil, Selamat Datang ' . $_SESSION['b'];
				
		header('Location:index.php'); // pindahkan ke halaman index
	}	
?>