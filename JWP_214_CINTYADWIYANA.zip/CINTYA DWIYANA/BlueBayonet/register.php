<?php include "header.php";?>
<!-- breadcrumbs -->
	<div class="breadcrumbs">
		<div class="container">
			<ol class="breadcrumb breadcrumb1 animated wow slideInLeft" data-wow-delay=".5s">
				<li><a href="index.php"><span class="glyphicon glyphicon-home" aria-hidden="true"></span>Home</a></li>
				<li class="active">Register</li>
			</ol>
		</div>
	</div>
<!-- //breadcrumbs -->
<!-- register -->
	<div class="register">
		<div class="container">
			<h3 class="animated wow zoomIn" data-wow-delay=".5s">Register</h3>
			
			<div class="login-form-grids">
				<form method="post" action="doregister.php" class="animated wow slideInUp" data-wow-delay=".5s">
					<input type="text" name="nama" placeholder="Nama..." required=" " >
					<input type="text" name="alamat" placeholder="Alamat..." required=" " >
					<input type="text" name="tgl" class="date" placeholder="Tanggal Lahir..." required=" " >
					<input type="time" name="jam mulai" placeholder="Jam Mulai..." required=" " >
					<input type="time" name="jam selesai" placeholder="Jam Selesai..." required=" " >
					<input type="text" name="usia" placeholder="usia...." required=" " >
					
					<select name="Lokasi" required>
						<option value="">-Pilih LOKASI-</option>
						<?php $sql = "select * from kota order by 2";
						$a = mysqli_query($dbc, $sql) or die(mysqli_error($dbc));
						while($b = mysqli_fetch_object($a)) { ?>
							<option value="<?php echo $b->kd_kota;?>"><?php echo $b->nama_kota;?></option>
						<?php } ?>
					</select>
						
					<input type="email" name="email" placeholder="Email..." required=" " >
					<input type="password" name="password" placeholder="Password..." required=" " >
					
					<input type="submit" value="Register">
				</form>
			</div>
		
		</div>
	</div>
<!-- //register -->
<?php include "footer.php";?>