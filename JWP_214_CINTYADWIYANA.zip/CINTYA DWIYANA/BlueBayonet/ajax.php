<?php
include "connect.php";
$kota = $_REQUEST['id'];
$sql = "select harga_ongkir from ongkir where kd_ongkir = '" . $kota . "'";
$ar = mysqli_query($dbc, $sql) or die(mysqli_error($dbc));
$br = mysqli_fetch_object($ar);
$harga_ongkir = $br->harga_ongkir;
echo number_format($harga_ongkir);
?>