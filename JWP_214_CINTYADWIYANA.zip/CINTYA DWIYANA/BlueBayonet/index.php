<?php include "header.php";?>
<div class="banner">
		<div class="container">
			<div class="banner-info animated wow zoomIn" data-wow-delay=".5s">
				<h3>&nbsp;</h3>
				<!DOCTYPE html>
<html>
<head>

</head>
<body>


<style>
body {
    background-image: url("images/3.jpg");
}
</style>

</body>
</html>
				<div class="wmuSlider example1">
					<div class="wmuSliderWrapper">
						<article style="position: absolute; width: 100%; opacity: 0;"> 
							<div class="banner-wrap">
								<div class="banner-info1">
									<p>.</p>
								</div>
							</div>
						</article>
						<article style="position: absolute; width: 100%; opacity: 0;"> 
							<div class="banner-wrap">
								<div class="banner-info1">
									<p></p>
								</div>
							</div>
						</article>
						<article style="position: absolute; width: 100%; opacity: 0;"> 
						  <div class="banner-wrap">
								<div class="banner-info1">
									<p>&nbsp;</p>
							  </div>
							</div>
						</article>
				  </div>
			  </div>
					<script src="js/jquery.wmuSlider.js"></script> 
					<script>
						$('.example1').wmuSlider();         
					</script> 
		  </div>
		</div>
	</div>
<div class="products">
	<div class="container">
		
		<div class="col-md-12 products-right">
			
			<div class="products-right-grids-bottom">
				<?php $sql = "select * from barang where nama_barang like '%$search%' order by 2";
				$a = mysqli_query($dbc, $sql) or die(mysqli_error($dbc));
				$i = 0;
				while($b = mysqli_fetch_object($a)){ ?>
			
				<?php if($i % 3 == 0) { ?>
				<div class="col-md-12 products-right-grids-bottom-grid">
				<?php }?>
					<div class="col-md-4">
						<div class="new-collections-grid1 products-right-grid1 animated wow slideInUp" data-wow-delay=".5s">
							<div class="new-collections-grid1-image">
							<?php $sql2 = "selecT * from detail_gambar a join gambar b on a.kd_gambar = b.kd_gambar where a.kd_barang ='" . $b->kd_barang . "'";
							$aa = mysqli_query($dbc, $sql2) or die(mysqli_error($dbc));
							$bb = mysqli_fetch_object($aa);
							if($bb) { ?>
								<a href="#" class="product-image"><img style="height:200px;" src="images/<?php echo $bb->nama_gambar;?>" alt=" " class="img-responsive"></a>
							<?php }?>
								
								
							<h4><a href="#"><?php echo $b->nama_barang;?></a></h4>
							<p><?php echo $b->keterangan;?></p>
							<div class="simpleCart_shelfItem products-right-grid1-add-cart">
								<p> <span class="item_price">Rp <?php echo number_format($b->harga_asli);?></span>
								<?php if(isset($_SESSION['a'])) { ?>
								<a class="" href="detailproduct.php?id=<?php echo $b->kd_barang;?>">BIAYA REGISTRASI </a>
								<?php }?>
								</p>
							</div>
						</div>
					</div>
					
					</div>
				<?php $i++; if($i % 4 == 0) { ?>
				</div>
				<?php }}?>
				
				<div class="clearfix"> </div>
			</div>
			
		</div>
		<div class="clearfix"> </div>
	</div>
</div>
<?php include "footer.php";?>