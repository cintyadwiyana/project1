<?php session_start(); include "connect.php"; // fungsi database

		
		$_SESSION['e'] = 'Terima kasih sudah mengirim pesan kepada kami';
				
		header('Location:contact.php'); // pindahkan ke halaman index
	
?>