<?php include "header.php";?>
<!-- //header -->
<!-- breadcrumbs -->
	<div class="breadcrumbs">
		<div class="container">
			<ol class="breadcrumb breadcrumb1 animated wow slideInLeft" data-wow-delay=".5s">
				<li><a href="index.php"><span class="glyphicon glyphicon-home" aria-hidden="true"></span>Home</a></li>
				<li class="active">Login</li>
			</ol>
		</div>
	</div>
<!-- //breadcrumbs -->
<!-- login -->
	<div class="login">
		<div class="container">
			<h3 class="animated wow zoomIn" data-wow-delay=".5s">Login Form</h3>
			<p class="est animated wow zoomIn" data-wow-delay=".5s"></p>
			<div class="login-form-grids animated wow slideInUp" data-wow-delay=".5s">
				<form method="post" action="dologin.php">
					<input name="email" type="email" placeholder="Email" autofocus required=" " >
					<input name="password" type="password" placeholder="Password" required=" " >
					<input type="submit" value="Login">
					<body>


<style>
body {
    background-image: url("images/3.jpg");
}
</style>

</body>
				</form>
			</div>			
		</div>
	</div>
<!-- //login -->
<!-- footer -->
	<?php include "footer.php";?>