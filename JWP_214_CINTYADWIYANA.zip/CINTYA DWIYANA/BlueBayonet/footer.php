<!-- footer -->
	<div class="footer">
		<div class="container">
			<div class="footer-grids">
				<div class="col-md-3 footer-grid animated wow slideInLeft" data-wow-delay=".5s">
					<h3>Tentang Kami</h3>
					<p>UNIVERSITAS ABC adalah perusahaan universitas yang didirikan oleh Judy  Christiana dan Zhen Rezky yang bergerak di bidang IT</p>
				<div class="col-md-3 footer-grid animated wow slideInLeft" data-wow-delay=".6s">
					<h3>Informasi Kontak</h3>
					<ul>
						<li><i class="glyphicon glyphicon-map-marker" aria-hidden="true"></i>Taman Permata Indah 1, PF. No.1<span></span></li>
						<li><i class="glyphicon glyphicon-envelope" aria-hidden="true"></i>UniversitasABC@gmail.com</li>
						<li><i class="glyphicon glyphicon-earphone" aria-hidden="true"></i>+822 138 95390</li>
					</ul>
				</div>
				
				<div class="clearfix"> </div>
			</div>
			<div class="footer-logo animated wow slideInUp" data-wow-delay=".5s">
				<h2><a href="index.html">UNIVERSITAS<span>ABC</span></a></h2>
			</div>
			<div class="copy-right animated wow slideInUp" data-wow-delay=".5s">
				<p>&copy 2017 UNIVERSITAS ABC</a></p>
			</div>
		</div>
	</div>
<!-- //footer -->
<?php if(isset($_SESSION['e'])){ ?>
<script>
	alert("<?php echo $_SESSION['e']; ?>");
</script>	

<?php unset($_SESSION['e']); } ?>
<script>
		$(document).ready(function() {			
			$(".date").datepicker(
				{
					dateFormat:'yy-mm-dd',
				}
			);
		});
	</script>
</body>
</html>