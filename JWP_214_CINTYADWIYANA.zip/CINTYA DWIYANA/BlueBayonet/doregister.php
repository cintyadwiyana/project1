<?php session_start(); include "connect.php"; // fungsi database
// digunakan untuk cek username + password
	$password = md5($_POST['password']);
	$email = $_POST['email'];
	$telp = $_POST['telp'];
	$nama = $_POST['nama'];
	$alamat = $_POST['alamat'];
	$tgl = $_POST['tgl'];
	$kota = $_POST['kota'];
	$kodepos = $_POST['kodepos'];
	$id = getNextIdFull('pelanggan', 'kd_pelanggan', 'PL');
	$count = 0;
	$result = mysqli_query($dbc, "select * from pelanggan where email = '$email'") or die( mysqli_error($dbc)); 

	$count = mysqli_num_rows($result); // hitung jumlah data
	
	if($count > 0) // jika 0 maka username password salah
	{		
		$_SESSION['e'] = 'Email sudah terdaftar, silakan login';
		header('Location:login.php');
	}
	else
	{		

		$data = array(
			"kd_pelanggan"=>$id,
			"password"=>($password),
			"email"=>$email,
			"nama_pelanggan"=>$nama,
			"telp_pelanggan"=>$telp,
			"tgl_lahir"=>$tgl,
			"alamat_pelanggan"=>$alamat,
			"kodepos_pelanggan"=>$kodepos,
			"kd_kota"=>$kota,
		);
		insert("pelanggan", $data);
		$_SESSION['e'] = 'Register berhasil, silakan login';
				
		header('Location:login.php'); // pindahkan ke halaman index
	}	
?>