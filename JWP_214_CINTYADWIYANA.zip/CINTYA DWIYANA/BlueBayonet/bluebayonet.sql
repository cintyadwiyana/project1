-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: May 26, 2017 at 03:17 PM
-- Server version: 10.1.19-MariaDB
-- PHP Version: 5.6.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `blue_bayonet`
--

-- --------------------------------------------------------

--
-- Table structure for table `barang`
--

CREATE TABLE `barang` (
  `kd_barang` char(12) NOT NULL,
  `nama_barang` varchar(30) NOT NULL,
  `harga_asli` int(11) NOT NULL,
  `keterangan` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `barang`
--

INSERT INTO `barang` (`kd_barang`, `nama_barang`, `harga_asli`, `keterangan`) VALUES
('BR00001', 'Williamson', 350000, 'It is perfectly suitable for both a shirt and a an outer.'),
('BR00002', 'Redbay', 350000, 'Stronger type of fabric used and\r\nincreases the durability of the product.');

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `kd_cart` int(11) NOT NULL,
  `kd_pelanggan` char(8) NOT NULL,
  `kd_barang` char(12) NOT NULL,
  `kd_cuttingan` char(7) NOT NULL,
  `kd_warna` char(7) NOT NULL,
  `kd_ukuran` char(7) NOT NULL,
  `jumlah` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `cuttingan`
--

CREATE TABLE `cuttingan` (
  `kd_cuttingan` char(7) NOT NULL,
  `nama_cuttingan` varchar(30) NOT NULL,
  `keterangan_cuttingan` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cuttingan`
--

INSERT INTO `cuttingan` (`kd_cuttingan`, `nama_cuttingan`, `keterangan_cuttingan`) VALUES
('CT00001', 'SlimFit', 'Cuttingan yang mengepas ke badan'),
('CT00002', 'Straight Fit', 'Cuttingan classic dari Blue Bayonets Co.');

-- --------------------------------------------------------

--
-- Table structure for table `detail_cuttingan`
--

CREATE TABLE `detail_cuttingan` (
  `kd_cuttingan` char(7) NOT NULL,
  `kd_barang` char(7) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `detail_cuttingan`
--

INSERT INTO `detail_cuttingan` (`kd_cuttingan`, `kd_barang`) VALUES
('CT00001', 'BR00001'),
('CT00002', 'BR00002');

-- --------------------------------------------------------

--
-- Table structure for table `detail_gambar`
--

CREATE TABLE `detail_gambar` (
  `kd_gambar` char(8) NOT NULL,
  `kd_barang` char(8) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `detail_gambar`
--

INSERT INTO `detail_gambar` (`kd_gambar`, `kd_barang`) VALUES
('GB00001', 'BR00002'),
('GB00001', 'BR00004'),
('GB00001', 'BRG00020'),
('GB00002', 'BR00001'),
('GB00002', 'BRG00020'),
('GB00003', 'BR00002'),
('GB00003', 'BRG00020'),
('GB00004', 'BR00001'),
('GB00004', 'BR00003'),
('GB00004', 'BRG00020'),
('GB00006', 'BRG00020');

-- --------------------------------------------------------

--
-- Table structure for table `detail_pemesanan`
--

CREATE TABLE `detail_pemesanan` (
  `kd_pemesanan` char(8) NOT NULL,
  `kd_barang` char(12) NOT NULL,
  `kd_cuttingan` char(7) NOT NULL,
  `kd_warna` char(7) NOT NULL,
  `kd_ukuran` char(7) NOT NULL,
  `jumlah` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `detail_pemesanan`
--

INSERT INTO `detail_pemesanan` (`kd_pemesanan`, `kd_barang`, `kd_cuttingan`, `kd_warna`, `kd_ukuran`, `jumlah`) VALUES
('PS00004', 'BR00001', 'CT00001', 'WR00002', 'UK00001', 2),
('PS00004', 'BR00002', 'CT00002', 'WR00001', 'UK00001', 3),
('PS00005', 'BR00001', 'CT00001', 'WR00001', 'UK00003', 1),
('PS00005', 'BR00002', 'CT00002', 'WR00001', 'UK00003', 1);

-- --------------------------------------------------------

--
-- Table structure for table `detail_ukuran`
--

CREATE TABLE `detail_ukuran` (
  `kd_ukuran` char(7) NOT NULL,
  `kd_barang` char(12) NOT NULL,
  `stok` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `detail_ukuran`
--

INSERT INTO `detail_ukuran` (`kd_ukuran`, `kd_barang`, `stok`) VALUES
('UK00001', 'BR00001', 10),
('UK00001', 'BR00002', 7),
('UK00001', 'BRG000201001', 0),
('UK00002', 'BR00001', 9),
('UK00002', 'BR00002', 14),
('UK00002', 'BRG000201001', 0),
('UK00003', 'BR00001', 27),
('UK00003', 'BR00002', 25),
('UK00003', 'BRG000201001', 0),
('UK00004', 'BR00001', 11),
('UK00004', 'BR00002', 14);

-- --------------------------------------------------------

--
-- Table structure for table `detail_warna`
--

CREATE TABLE `detail_warna` (
  `kd_warna` char(7) NOT NULL,
  `kd_barang` char(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `detail_warna`
--

INSERT INTO `detail_warna` (`kd_warna`, `kd_barang`) VALUES
('WR00001', 'BR00002'),
('WR00002', 'BR00001');

-- --------------------------------------------------------

--
-- Table structure for table `diskon`
--

CREATE TABLE `diskon` (
  `kd_diskon` char(7) NOT NULL,
  `nama_diskon` varchar(30) NOT NULL,
  `keterangan_diskon` varchar(100) NOT NULL,
  `tgl_mulai` date NOT NULL,
  `tgl_akhir` date NOT NULL,
  `jumlah_diskon` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `diskon`
--

INSERT INTO `diskon` (`kd_diskon`, `nama_diskon`, `keterangan_diskon`, `tgl_mulai`, `tgl_akhir`, `jumlah_diskon`) VALUES
('CT00002', 'DISKONTAHUNAN', 'Diskon akhir tahun, mendapatkan potongan 70% untuk semua produk', '2016-12-28', '2017-01-25', 70);

-- --------------------------------------------------------

--
-- Table structure for table `gambar`
--

CREATE TABLE `gambar` (
  `kd_gambar` char(8) NOT NULL,
  `nama_gambar` varchar(30) NOT NULL,
  `keterangan_gambar` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `gambar`
--

INSERT INTO `gambar` (`kd_gambar`, `nama_gambar`, `keterangan_gambar`) VALUES
('GB00002', '2.jpg', 'Denim'),
('GB00003', '15.jpg', 'RedbayonetsJPG');

-- --------------------------------------------------------

--
-- Table structure for table `kota`
--

CREATE TABLE `kota` (
  `kd_kota` char(7) NOT NULL,
  `nama_kota` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `kota`
--

INSERT INTO `kota` (`kd_kota`, `nama_kota`) VALUES
('KT00002', 'Jakartas'),
('KT00003', 'Bandung'),
('KT00004', 'Pontianak'),
('KT00005', 'Surabaya'),
('KT00006', 'Padang');

-- --------------------------------------------------------

--
-- Table structure for table `ongkir`
--

CREATE TABLE `ongkir` (
  `kd_ongkir` char(8) NOT NULL,
  `harga_ongkir` int(11) NOT NULL,
  `kd_kota` char(8) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ongkir`
--

INSERT INTO `ongkir` (`kd_ongkir`, `harga_ongkir`, `kd_kota`) VALUES
('OK00001', 10000, 'KT00002'),
('OK00002', 20000, 'KT00003'),
('OK00003', 45000, 'KT00004'),
('OK00004', 15000, 'KT00005');

-- --------------------------------------------------------

--
-- Table structure for table `pelanggan`
--

CREATE TABLE `pelanggan` (
  `kd_pelanggan` char(8) NOT NULL,
  `nama_pelanggan` varchar(50) NOT NULL,
  `alamat_pelanggan` varchar(80) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(100) NOT NULL,
  `tgl_lahir` date NOT NULL,
  `telp_pelanggan` varchar(20) NOT NULL,
  `kodepos_pelanggan` varchar(20) NOT NULL,
  `kd_kota` char(8) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pelanggan`
--

INSERT INTO `pelanggan` (`kd_pelanggan`, `nama_pelanggan`, `alamat_pelanggan`, `email`, `password`, `tgl_lahir`, `telp_pelanggan`, `kodepos_pelanggan`, `kd_kota`) VALUES
('PL00001', 'x', 'x', 'x@x.com', '9dd4e461268c8034f5c8564e155c67a6', '2016-11-28', '123', '121', 'KT00002'),
('PL00002', 'Judy Christiana', 'Taman pertama indah 1', 'judy@gmail.com', '9c7c6e62c30d0c5ab3e0f952033046d5', '2016-11-21', '082213895390', '79122', 'KT00002'),
('PL00003', 'Zhen Rezky', 'Jalan pembangunan no 17', 'zhenrezky@gmail.com', '53abc67c4b8f5b6f4818b70b4d923b00', '1995-02-02', '082213895390', '11470', 'KT00004'),
('PL00004', 'Gibby', 'tawakal ujung blok c1. no43', 'gibby@gmail.com', 'd85437a34ce11ba2a93f1c14fcd86949', '1995-01-11', '082413654951', '11440', 'KT00002'),
('PL00005', 'Handy Lesmana', 'Jln. Pejagalan no 2', 'handy@gmail.com', '16f198404de4bb7b994f16b84e30f14f', '1994-07-14', '089564512457', '36542', 'KT00004');

-- --------------------------------------------------------

--
-- Table structure for table `pembayaran`
--

CREATE TABLE `pembayaran` (
  `id_pembayaran` char(7) NOT NULL,
  `tgl_pembayaran` date NOT NULL,
  `jumlah_pembayaran` int(11) NOT NULL,
  `atas_nama` varchar(30) NOT NULL,
  `no_rekening` varchar(20) NOT NULL,
  `nama_bank` varchar(10) NOT NULL,
  `id_pemesanan` char(7) NOT NULL,
  `foto` varchar(50) NOT NULL,
  `tujuan_transfer` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pembayaran`
--

INSERT INTO `pembayaran` (`id_pembayaran`, `tgl_pembayaran`, `jumlah_pembayaran`, `atas_nama`, `no_rekening`, `nama_bank`, `id_pemesanan`, `foto`, `tujuan_transfer`) VALUES
('BY00002', '2017-01-02', 7010000, 'Mandiri', '126456498', 'BCa', 'PS00001', 'P_20161214_140502.jpg', ''),
('BY00003', '2017-01-02', 395000, 'Handy lesmana', '5689744210', 'BNI', 'PS00003', 'Screenshot_2016-12-29-10-19-00-883_com.google.andr', ''),
('BY00004', '2017-01-02', 1760000, 'Judy Chris', '789451254', 'BCa', 'PS00004', 'Screenshot_2016-12-13-08-55-12-566_com.bca.png', ''),
('BY00005', '2017-01-21', 710000, 'dhoko', '1235', 'mandrii', 'PS00005', 'advan.jpeg', 'BCA - 817-061-5329');

-- --------------------------------------------------------

--
-- Table structure for table `pemesanan`
--

CREATE TABLE `pemesanan` (
  `kd_pemesanan` char(8) NOT NULL,
  `tgl_pemesanan` date NOT NULL,
  `nama_penerima` varchar(30) NOT NULL,
  `alamat_penerima` varchar(100) NOT NULL,
  `notelp_penerima` int(11) NOT NULL,
  `kodepos_penerima` varchar(5) NOT NULL,
  `status_pemesanan` varchar(50) NOT NULL,
  `kd_diskon` char(8) NOT NULL,
  `kd_pelanggan` char(8) NOT NULL,
  `kd_ongkir` char(8) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pemesanan`
--

INSERT INTO `pemesanan` (`kd_pemesanan`, `tgl_pemesanan`, `nama_penerima`, `alamat_penerima`, `notelp_penerima`, `kodepos_penerima`, `status_pemesanan`, `kd_diskon`, `kd_pelanggan`, `kd_ongkir`) VALUES
('PS00001', '2017-01-02', 'Gibby', 'tawakal ujung blok c1. no43', 2147483647, '11440', 'Sudah Dikirim', '', 'PL00004', 'OK00001'),
('PS00002', '2017-01-02', 'Handy Lesmana', 'Jln. Pejagalan no 2', 2147483647, '36542', 'Menunggu Pembayaran', '', 'PL00005', 'OK00002'),
('PS00003', '2017-01-02', 'Handy Lesmana', 'Jln. Pejagalan no 2', 2147483647, '36542', 'Sudah Dikirim', '', 'PL00005', 'OK00003'),
('PS00004', '2017-01-02', 'Judy Christiana', 'Taman pertama indah 1', 2147483647, '79122', 'Sudah Dikirim', '', 'PL00002', 'OK00001'),
('PS00005', '2017-01-21', 'x', 'x', 123, '121', 'Verifikasi Pembayaran', '', 'PL00001', 'OK00001');

-- --------------------------------------------------------

--
-- Table structure for table `pengiriman`
--

CREATE TABLE `pengiriman` (
  `id_pengiriman` char(7) NOT NULL,
  `tgl_pengiriman` date NOT NULL,
  `no_resi` varchar(20) NOT NULL,
  `id_pembayaran` char(7) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pengiriman`
--

INSERT INTO `pengiriman` (`id_pengiriman`, `tgl_pengiriman`, `no_resi`, `id_pembayaran`) VALUES
('KR00001', '2016-12-28', 'dfsdfdsfds', 'BY00001'),
('KR00002', '2017-01-02', '265', 'BY00002'),
('KR00003', '2017-01-02', '3245556', 'BY00003'),
('KR00004', '2017-01-02', '336547864', 'BY00004');

-- --------------------------------------------------------

--
-- Table structure for table `ukuran`
--

CREATE TABLE `ukuran` (
  `kd_ukuran` char(7) NOT NULL,
  `nama_ukuran` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ukuran`
--

INSERT INTO `ukuran` (`kd_ukuran`, `nama_ukuran`) VALUES
('UK00001', 'S'),
('UK00002', 'M'),
('UK00003', 'L'),
('UK00004', 'XL'),
('UK00005', 'XXL');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `username` varchar(30) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`username`, `password`) VALUES
('admin', '9dd4e461268c8034f5c8564e155c67a6'),
('zhen', '21232f297a57a5a743894a0e4a801fc3');

-- --------------------------------------------------------

--
-- Table structure for table `warna`
--

CREATE TABLE `warna` (
  `kd_warna` char(7) NOT NULL,
  `nama_warna` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `warna`
--

INSERT INTO `warna` (`kd_warna`, `nama_warna`) VALUES
('WR00001', 'Merah'),
('WR00002', 'Indigo');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `barang`
--
ALTER TABLE `barang`
  ADD PRIMARY KEY (`kd_barang`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`kd_cart`);

--
-- Indexes for table `cuttingan`
--
ALTER TABLE `cuttingan`
  ADD PRIMARY KEY (`kd_cuttingan`);

--
-- Indexes for table `detail_cuttingan`
--
ALTER TABLE `detail_cuttingan`
  ADD PRIMARY KEY (`kd_cuttingan`,`kd_barang`);

--
-- Indexes for table `detail_gambar`
--
ALTER TABLE `detail_gambar`
  ADD PRIMARY KEY (`kd_gambar`,`kd_barang`);

--
-- Indexes for table `detail_pemesanan`
--
ALTER TABLE `detail_pemesanan`
  ADD PRIMARY KEY (`kd_pemesanan`,`kd_barang`);

--
-- Indexes for table `detail_ukuran`
--
ALTER TABLE `detail_ukuran`
  ADD PRIMARY KEY (`kd_ukuran`,`kd_barang`);

--
-- Indexes for table `detail_warna`
--
ALTER TABLE `detail_warna`
  ADD PRIMARY KEY (`kd_warna`,`kd_barang`);

--
-- Indexes for table `diskon`
--
ALTER TABLE `diskon`
  ADD PRIMARY KEY (`kd_diskon`);

--
-- Indexes for table `gambar`
--
ALTER TABLE `gambar`
  ADD PRIMARY KEY (`kd_gambar`);

--
-- Indexes for table `kota`
--
ALTER TABLE `kota`
  ADD PRIMARY KEY (`kd_kota`);

--
-- Indexes for table `ongkir`
--
ALTER TABLE `ongkir`
  ADD PRIMARY KEY (`kd_ongkir`);

--
-- Indexes for table `pelanggan`
--
ALTER TABLE `pelanggan`
  ADD PRIMARY KEY (`kd_pelanggan`);

--
-- Indexes for table `pembayaran`
--
ALTER TABLE `pembayaran`
  ADD PRIMARY KEY (`id_pembayaran`);

--
-- Indexes for table `pemesanan`
--
ALTER TABLE `pemesanan`
  ADD PRIMARY KEY (`kd_pemesanan`);

--
-- Indexes for table `pengiriman`
--
ALTER TABLE `pengiriman`
  ADD PRIMARY KEY (`id_pengiriman`);

--
-- Indexes for table `ukuran`
--
ALTER TABLE `ukuran`
  ADD PRIMARY KEY (`kd_ukuran`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `warna`
--
ALTER TABLE `warna`
  ADD PRIMARY KEY (`kd_warna`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `kd_cart` int(11) NOT NULL AUTO_INCREMENT;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
