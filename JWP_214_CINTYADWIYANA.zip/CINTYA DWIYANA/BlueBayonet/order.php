<?php include "header.php";
$id = $_SESSION['a'];
$total = 0;
?>
<!-- //header -->
<!-- breadcrumbs -->
	<div class="breadcrumbs">
		<div class="container">
			<ol class="breadcrumb breadcrumb1 animated wow slideInLeft" data-wow-delay=".5s">
				<li><a href="index.php"><span class="glyphicon glyphicon-home" aria-hidden="true"></span>Home</a></li>
				<li class="active">Pesanan Saya</li>
			</ol>
		</div>
	</div>
<!-- //breadcrumbs -->
<!-- checkout -->
	<div class="checkout">
		<div class="container">
			
			<div class="checkout-right animated wow slideInUp" data-wow-delay=".5s">
				<table class="timetable_sub">
					<thead>
						<tr>
							<th>No.</th>	
							<th>No Pesanan</th>
							<th>Tanggal</th>
							<th>Penerima</th>
							<th>Alamat</th>
							<th>Telp</th>							
							<th>Kode Pos</th>
							<th>Kota</th>
							<th>Status</th>
							<th>Resi</th>
							<th>Detail</th>
						</tr>
					</thead>
					<body>
	
				<form>
			<<table class="timetable_sub">
					
			<thead>
				<tr>
					<td>Nama tim</td>
					<td>JADWAL PERTANDINGAN</td>
					<td>KATEGORI</td>
				</tr>
			</thead>
				
				<tbody>
				
				<tr>
					<td>Cintya GROUP</td>
					<td>SELASA</td>
					<td>BAZAR</td>
				</tr>
				
				<tr>
					<td>ANDI GROUP</td>
					<td>RABU</td>
					<td>DOTA</td>
				</tr>
				
				<tr>
					<td>ANIS GROUP</td>
					<td>RABU</td>
					<td>PES</td>
				</tr>
				
				<tr>
					<td>NITA GROUP</td>
					<td>KAMIS</td>
					<td>DEBAT</td>
				</tr>
				
				<tr>
					<td>prita GROUP</td>
					<td>KAMIS</td>
					<td>DEBAT</td>
				</tr>
				<tr>
					<td>ANANG GROUP</td>
					<td>KAMIS</td>
					<td>pes</td>
				</tr>
				</tbody>
			</table>	
	</body>
					<?php $no = 1;
					$sql = "select * from pemesanan a join ongkir b on a.kd_ongkir = b.kd_ongkir join kota c on c.kd_kota = b.kd_kota 
					left join pembayaran d on a.kd_pemesanan = d.id_pemesanan
					left join pengiriman e on d.id_pembayaran = e.id_pembayaran
					where kd_pelanggan = '$id' order by a.kd_pemesanan";
					$a = mysqli_query($dbc, $sql) or die(mysqli_error($dbc));
					while($b = mysqli_fetch_object($a)) {?>
					<tr class="rem1">
						<td class="invert"><?php echo $no++;?></td>
						<td class="invert-image">
						<?php echo $b->kd_pemesanan;?>
						</td>
						<td class="invert-image">
						<?php echo date('d-M-y', strtotime($b->tgl_pemesanan));?>
						</td>
						<td class="invert">
							<?php echo $b->nama_penerima;?>
						</td>						
						<td class="invert">
							<?php echo $b->alamat_penerima;?>
						</td>	
						<td class="invert">
							<?php echo $b->notelp_penerima;?>
						</td>	
						<td class="invert">
							<?php echo $b->kodepos_penerima;?>
						</td>	
						<td class="invert">
							<?php echo $b->nama_kota;?>
						</td>	
						<td class="invert">
							<?php echo $b->status_pemesanan;?>
						</td>
						<td class="invert">
							<?php echo $b->no_resi;?>
						</td>
						<td class="invert">
							<a href="detailorder.php?id=<?php echo $b->kd_pemesanan;?>">Detail</a></td>
						</td>							
					</tr>
					<?php }?>
								<!--quantity-->
				</table>
				<p>&nbsp;</p>
				<p>&nbsp;</p>
				<p>&nbsp;</p>
				<p>&nbsp;</p>
				<p>&nbsp;</p>
				<table width="413" border="0" align="center">
				  <tbody>
				    <tr>
				      <td colspan="3">Nomor Rekening Blue Bayonets Co. di bawah ini :</td>
			        </tr>
				    <tr>
				      <td colspan="3">&nbsp;</td>
			        </tr>
				    <tr>
				      <td width="198"><img src="images/Mandiri.png" width="159" height="48" alt=""/></td>
				      <td width="144">&nbsp;</td>
				      <td width="57">&nbsp;</td>
			        </tr>
				    <tr>
				      <td align="center"> 900-00-3640-141-3</td>
				      <td>a/n Zhen Rezky</td>
				      <td>&nbsp;</td>
			        </tr>
				    <tr>
				      <td height="40">&nbsp;</td>
				      <td>&nbsp;</td>
				      <td>&nbsp;</td>
			        </tr>
				    <tr>
				      <td><img src="images/logo-bank-bca1.jpg" width="145" height="48" alt=""/></td>
				      <td>&nbsp;</td>
				      <td>&nbsp;</td>
			        </tr>
				    <tr>
				      <td align="center">817-061-5329</td>
				      <td>a/n Zhen Rezky </td>
				      <td>&nbsp;</td>
			        </tr>
				    <tr>
				      <td>&nbsp;</td>
				      <td>&nbsp;</td>
				      <td>&nbsp;</td>
			        </tr>
				    <tr>
				      <td>&nbsp;</td>
				      <td>&nbsp;</td>
				      <td>&nbsp;</td>
			        </tr>
				    <tr>
				      <td colspan="3">Jangan lupa Konfirmasi Pesanan anda setelah melakukan pembayaran</td>
			        </tr>
			      </tbody>
			  </table>
				<p>&nbsp;</p>
			</div>
			
		</div>
	</div>
<!-- //checkout -->
<?php include "footer.php";?>