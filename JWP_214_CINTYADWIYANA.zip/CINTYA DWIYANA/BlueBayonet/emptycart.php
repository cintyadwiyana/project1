<?php session_start();
include "connect.php";
$id = $_SESSION['a'];
$sql = "delete from cart where kd_pelanggan = '$id'";
mysqli_query($dbc, $sql) or die(myqsli_error($dbc));
header('Location:index.php');
exit();
?>