<?php include "connect.php";session_start();

$kd_pelanggan=$_SESSION['a'];
$kd_barang=$_POST['id'];
$qty=$_POST['qty'];
$c=$_POST['c'];
$u=$_POST['u'];
$w=$_POST['w'];

$sql = "select * from cart 
where kd_pelanggan ='$kd_pelanggan' and kd_barang = '$kd_barang' and kd_ukuran = '$u' and kd_cuttingan = '$c' and kd_warna = '$w'";

$temp = mysqli_query($dbc, $sql)or die(mysqli_error($dbc));
$x = mysqli_fetch_object($temp);

if($x)
{
		$sql = "update cart set jumlah = jumlah + $qty where kd_barang = '$kd_barang' and kd_ukuran = '$u' and kd_cuttingan = '$c' and kd_warna = '$w' and kd_pelanggan = '$kd_pelanggan'";		
}
else{
$sql = "insert into cart(kd_pelanggan, kd_barang, jumlah, kd_ukuran, kd_cuttingan, kd_warna) 
values('$kd_pelanggan', '$kd_barang', '$qty', '$u', '$c', '$w')";
}


mysqli_query($dbc, $sql) or die(mysqli_error($dbc));
echo "<script>alert('Pesanan berhasil ditambahkan ke dalam cart');location.href='detailproduct.php?id=$kd_barang';</script>";
?>