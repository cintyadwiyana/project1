<?php include "header.php";
$id = $_GET['id'];
$sql = "select* from barang b  where b.kd_barang = '$id'";
$row = mysqli_query($dbc, $sql) or die(mysqli_error($dbc));
$r = mysqli_fetch_object($row);
?>
<!-- //header -->
<!-- breadcrumbs -->
	<div class="breadcrumbs">
		<div class="container">
			<ol class="breadcrumb breadcrumb1 animated wow slideInLeft" data-wow-delay=".5s">
				<li><a href="index.php"><span class="glyphicon glyphicon-home" aria-hidden="true"></span>Home</a></li>
				<li class="active">Detail Product</li>
			</ol>
		</div>
	</div>
<!-- //breadcrumbs -->
<!-- single -->
	<div class="single">
		<div class="container">
			
			<div class="col-md-12 single-right">
				<div class="col-md-5 single-right-left animated wow slideInUp" data-wow-delay=".5s">
					<div class="flexslider">
						<ul class="slides">
						<?php $sql2 = "select * from detail_gambar a join gambar b on a.kd_gambar = b.kd_gambar where kd_barang ='$id'";
						$aa = mysqli_query($dbc, $sql2) or die(mysqli_error($dbc));
						while($bb = mysqli_fetch_object($aa)) {?>
						
							<li data-thumb="images/<?php echo $bb->nama_gambar;?>">
								<div class="thumb-image"> <img src="images/<?php echo $bb->nama_gambar;?>" data-imagezoom="true" class="img-responsive"> </div>
							</li>
						<?php }?>
						</ul>
					</div>
					<!-- flixslider -->
						<script defer src="js/jquery.flexslider.js"></script>
						<link rel="stylesheet" href="css/flexslider.css" type="text/css" media="screen" />
						<script>
						// Can also be used with $(document).ready()
						$(window).load(function() {
						  $('.flexslider').flexslider({
							animation: "slide",
							controlNav: "thumbnails"
						  });
						});
						</script>
					<!-- flixslider -->
				</div>
				<div class="col-md-7 single-right-left simpleCart_shelfItem animated wow slideInRight" data-wow-delay=".5s">
					<h3><?php echo $r->nama_barang;?></h3>
					<h4><span class="item_price">Rp <?php echo number_format($r->harga_asli);?></h4>
					<form method="post" action="dobuy.php">
					<p>Cuttingan :  <select name="c" class="form-control" required>
														<?php 
														$sql ="select * from cuttingan where kd_cuttingan in (select kd_cuttingan from detail_cuttingan where kd_barang = '$id') order by nama_cuttingan";
														$x = mysqli_query($dbc, $sql) or die(mysqli_error($dbc));
														while($y = mysqli_fetch_object($x))
														{
														
														?>
														<option value="<?php echo $y->kd_cuttingan;?>"><?php echo $y->nama_cuttingan;?></option>
														<?php } ?>
													</select> <br/>
					Ukuran : <select name="u" class="form-control" required>
														<?php 
														$sql ="select * from ukuran where kd_ukuran in (select kd_ukuran from detail_ukuran where kd_barang = '$id') order by nama_ukuran";
														$x = mysqli_query($dbc, $sql) or die(mysqli_error($dbc));
														while($y = mysqli_fetch_object($x))
														{
														
														?>
														<option value="<?php echo $y->kd_ukuran;?>"><?php echo $y->nama_ukuran;?></option>
														<?php } ?>
													</select> <br/>
					Warna : <select name="w" class="form-control" required>
														<?php 
														$sql ="select * from warna where kd_warna in (select kd_warna from detail_warna where kd_barang = '$id') order by nama_warna";
														$x = mysqli_query($dbc, $sql) or die(mysqli_error($dbc));
														while($y = mysqli_fetch_object($x))
														{
														
														?>
														<option value="<?php echo $y->kd_warna;?>"><?php echo $y->nama_warna;?></option>
														<?php } ?>
													</select> <br/>
					</p>
					<div class="description">
						<h5><i>Keterangan</i></h5>
						<p><?php echo $r->keterangan;?></p>
					</div>
					
					
					<div class="occasion-cart">
						
						
						<input type="hidden" name="id" value="<?php echo $r->kd_barang;?>"/>
						<input type="number" style="width:100px" name="qty" value="1" min="1"/>
						<input type="submit"  class="item_add" value="BELI"/>
						
					</div>
					</form>
				</div>
				<div class="clearfix"> </div>
				
			</div>
			<div class="clearfix"> </div>
		</div>
	</div>
<!-- //single -->
<!-- single-related-products -->
	<?php include "footer.php";?>