<?php include "header.php";
$diskon = "";
if(isset($_REQUEST['diskon']))
{
	$diskon = $_REQUEST['diskon'];
}

if(!empty($diskon))
{
	$sql = "select * from diskon where current_date between tgl_mulai and tgl_akhir and kd_diskon ='" . $diskon . "'";
	$a=  mysqli_query($dbc, $sql) or die(myqsli_error($dbc));
	$b = mysqli_fetch_object($a);
	if(!$b)
	{
		$_SESSION['e'] = 'Kode Diskon Salah';
		echo '<meta http-equiv="refresh" content="0; URL=checkout.php">';
		exit();
	}
}

?>
<!-- breadcrumbs -->
	<div class="breadcrumbs">
		<div class="container">
			<ol class="breadcrumb breadcrumb1 animated wow slideInLeft" data-wow-delay=".5s">
				<li><a href="index.php"><span class="glyphicon glyphicon-home" aria-hidden="true"></span>Home</a></li>
				<li class="active">Checkout</li>
			</ol>
		</div>
	</div>
<!-- //breadcrumbs -->
<!-- register -->
	<div class="register">
		<div class="container">
			<h3 class="animated wow zoomIn" data-wow-delay=".5s">Checkout</h3>
			<?php $sql = "select * from pelanggan where kd_pelanggan = '" . $_SESSION['a'] . "'";
			$a = mysqli_query($dbc, $sql) or die(mysqli_error($dbc));
			$b = mysqli_fetch_object($a);
			?>
			<div class="login-form-grids">
				<form method="post" action="docheckout.php" class="animated wow slideInUp" data-wow-delay=".5s">
					Nama Penerima <input value="<?php echo $b->nama_pelanggan;?>" type="text" name="nama" placeholder="Nama Penerima..." required=" " >
					Alamat Penerima <input value="<?php echo $b->alamat_pelanggan;?>" type="text" name="alamat" placeholder="Alamat..." required=" " >
					Telp Penerima <input value="<?php echo $b->telp_pelanggan;?>" type="text" name="telp" placeholder="Telp..." required=" " >
					Kode Pos<input value="<?php echo $b->kodepos_pelanggan;?>"  type="text" name="kodepos" placeholder="Kode Pos..." required=" " >
					Kota Pengiriman<select id="kota" name="ongkir" required>
						<option value="">-Pilih Kota Pengiriman-</option>
						<?php $sql = "select * from kota a join ongkir b on a.kd_kota = b.kd_kota order by 2";
						$a = mysqli_query($dbc, $sql) or die(mysqli_error($dbc));
						while($bb = mysqli_fetch_object($a)) { ?>
							<option <?php if($bb->kd_kota == $b->kd_kota) echo 'selected';?> value="<?php echo $bb->kd_ongkir;?>"><?php echo $bb->nama_kota;?></option>
						<?php } ?>
					</select>
					Ongkir : Rp <span id="price"></span>
					<input type="hidden" name="diskon" value="<?php echo $diskon;?>"/>
					<input type="submit" value="Checkout">
				</form>
			</div>
		
		</div>
	</div>
	<script>
		$(document).ready(function()
		{			
			$("#kota").change(function(){
				var id = $(this).val();				
				$.ajax({
					type: "GET",
					data: {
						
						id:id,
					},
					url: 'ajax.php',					
					success: function(json) {
						
						$("#price").text(json);
					}				
				});
			});
			$("#kota").trigger('change');
		});
	</script>
<!-- //register -->
<?php include "footer.php";?>