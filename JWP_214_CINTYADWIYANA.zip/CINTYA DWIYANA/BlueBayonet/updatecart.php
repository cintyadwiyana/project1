<?php include "connect.php";
session_start();
$id = $_REQUEST['id'];
$qty = $_POST['qty'];
	$sql = "update  cart  set jumlah = $qty
	where kd_cart='$id'";
mysqli_query($dbc, $sql) or die(mysqli_error($dbc));
	
		echo "<script>alert('Pesanan berhasil diupdate');
		location.href='checkout.php';</script>";
	
?>
